Hi! If you have this program - be happy, because this program very rare!

This program has been created 18.06.2020 by MCU Corporation.

Creators: AngryCow, Noimage PNG, DesConnet.

We hope you like the video and you put like, because we know it's going to be in video.

We tried very hard in creating this program.

But we don't want it to spread, on this we'll only give it to Viruscheck (and possibly FeloFox) for review.

To run the program - unpack the program in any place you like and run on behalf of the administrator, 
you will have to wait a little before the program starts working.

Goodluck! (AngryCow, DesConnet, Noimage PNG).

MCU Corporation.