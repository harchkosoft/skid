Solarum.exe is a sophisticated malware program developed in C#. The development process, which spanned
over two months, was both challenging and enjoyable.

Solarum.exe is designed to inflict damage on any machine running Windows XP 32-bit (x86) and above. For
any inquiries regarding this malware, feel free to reach out to me on Discord at lyrik_lyrik. However, please
note that I will not provide any information or assistance related to the malware.

All graphical effects and sounds were meticulously crafted in C# from scratch. I may embark on another
project soon-stay tuned!

Special thanks to my friends: Dark-Tik, Ebx1, Triptych, mr. virus, Sclerosis, Deep Freeze, and CorXnull.

A shoutout to (nikitpad & Leurak), who is cool.