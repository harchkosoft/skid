 _   _ _ _                 _     _      
| \ | (_) |               (_)   | |     
|  \| |_| |_ _ __ _____  ___  __| | ___ 
| . ` | | __| '__/ _ \ \/ / |/ _` |/ _ \
| |\  | | |_| | | (_) >  <| | (_| |  __/
|_| \_|_|\__|_|  \___/_/\_\_|\__,_|\___|

-------------------------------------------------------------------------------------
Hello there!
What you have is Nitroxide, a GDI malware made by CiberBoy.
It is coded in C# and the MBR in ASM.
This malware is like a trip, and it has original GDI effects 
along with some bytebeats.
This malware can only run on Windows XP, x64 is recommended 
but it also works on x86. If you run on other OS, it will flood
your screen with popups and shakes for 5 seconds then destroy PC.
You'll need NET Framework 4.
This malware took me 5 days to make like coding 2 hours a day.
-------------------------------------------------------------------------------------
WARNING!
YOU MUSTN'T SHARE THIS MALWARE WITH ANYBODY OR GIVE ANY
DOWNLOAD LINK! DOING THAT IS VIOLATING THIS MALWARE TERMS!
ALSO, YOU MUSTN'T DO ANY VIDEO WITHOUT CIBERBOY'S PERMISSION!
-------------------------------------------------------------------------------------
BE CAREFUL!
This malware is destructive and should only be ran on VM! 
CiberBoy won't make responsible of damages caused by the 
incorrect use of this malware.
It can destroy the MBR, the registry, system32 and encrypt files.
-------------------------------------------------------------------------------------
CREDITS and DETAILS:
 - All GDI is coded by CiberBoy in C#
 - MBR is made by MalwareLab in ASM and it's interactive
 - Bytebeats are also made by CiberBoy
 - Text payload uses part of the code of TrojanXD
-------------------------------------------------------------------------------------
This will probably be my last GDI malware. Why?
Well, I think GDI became boring at all, everything is
just the same and skids have taken everything.
From now on, I'll still do malwares, but different type.
Of course, they will have GDI, but not only that.
-------------------------------------------------------------------------------------
Have a good day!
CiberBoy :)

