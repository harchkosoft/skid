Author: Java / NullException
Malware type: GDI trojan
Required components: .NET Framework 2.0
OS support: Windows XP

Details:
Every execution the random MBR payload is loaded. It also include puzzle in one of the payloads.

Overwrites all registry values to it's own name.

Write files with ".phantasm" extension to System32, it writes only 95 files with that extension. Java decided to write 95 files, because the original Phantasm was 95th FMV (Fan Malware Viewer) on Siam Alam channel.

OS detection.
Disable Task Manager.