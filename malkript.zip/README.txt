Hey there! 
What you have in your computer is Malkript, a private GDI malware made by CiberBoy.
This malware is made on C# the GDI and bytebeat and ASM the MBR (Made by MalwareLab).
.NET framework 4 is needed to run this malware correctly.
This sample should be ran ONLY on Windows XP and 7. Running on other OS will instantly destroy
your files and show a different MBR, destroying also all the system.
This malware has the capability to produce GDI effects, splitted into 9 payloads, combining some of them.
After this 9 payloads are completed, ntdll.dll will be used to terminate the system using a BSOD.
The first payload is the destruction part. It can:
 - Detect your OS and destroy if not XP or 7
 - Use critical process to avoid getting killed
 - Delete System32 folder completely
 - Encrypt the user directory using AES
 - Delete the desktop shortcuts
 - Delete the HKCR
 - Delete the HKCU
 - Overwrite MBR with interactive MBR (made by MalwareLab ❤️)
After this destruction finishes, which it can take around 7 seconds because encrypting files
takes some time, the GDI part starts. The GDI lasts around 220 seconds, and it plays some GDI along with some bytebeat,
and consists of the following payloads:
 1. Colorful hatchbrush pixelation
 2. Blurry screen with error sound
 3. Blackout with color flashing
 4. Sinewave with color flashing
 5. Sinewave + pixelation + random point drawing
 6. Text drawing with random positions and random points.
 7. Inverted color text with error sounds
 8. Chaos: Almost all the effects will be now applied at the same time along with a
    powerful sound bytebeat. This final destruction lasts 50 seconds, and after it, BSOD.
    After this, the system is cooked, and the interactive MBR will show up.

This malware took me a month and half making, so I hope you enjoyed it. This is my first malware ever.

CREDITS:
 - MalwareLab for sinewave and MBR
 - CYBER SOLDIER for hatch brush
Everything else is made by me, CiberBoy

I hope you enjoy Malkript!